<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'wordpress' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'root' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', '' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '</L.<{H9{|Sv0^s[M9X,AWQ0O#XN 5Gj&)>mZlL,rI:i~vU?$E-}fN=K,n|Fuh]A' );
define( 'SECURE_AUTH_KEY',  'DW #DKN:z@d3SY[#=B41K5m*R6N3X/p6Ipr9HuHl2FEI5B(|Mzc)np(vT[NpddIA' );
define( 'LOGGED_IN_KEY',    'X;NsGL+8loWo([ _Pt}R]WX>!ghIAjpFy@,clvY >-n$Z(xr/FP5@rY[~6P$Uym9' );
define( 'NONCE_KEY',        'nV:uQ?kf*|HDhN;7kvvzUz9~-yiDojCfS,#YKLPr#P2cmz4~Wm*TD~t`@W=7i&Hp' );
define( 'AUTH_SALT',        'zm-[aoD=i1K!zL~Vw?wG+|g0Gd0E-LtxE?=IU:[H`h#gvTP5K2r+:r5`?z [W0)J' );
define( 'SECURE_AUTH_SALT', ' o2qx.fDO{[fsGV-^#6=^Wz!WL23IB1+m! xDJd6-G8pm_+g)7un.:NXeUbkzHd6' );
define( 'LOGGED_IN_SALT',   'v6x/a2bcsbg3oG{!+BOke$|fMvF8Zg`_g<R4}^(FSSL<8`iY;SRTZu/UyrM:rWTP' );
define( 'NONCE_SALT',       'hUC|m>p}p_UID7I;TKTaEegaT)k(](JT&Gx=Oqt`{hL$}E^rXRlGIzBs3#zq8p_)' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
